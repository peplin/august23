/*
    TUIO Simulator - part of the reacTIVision project
    http://reactivision.sourceforge.net/

    Copyright (c) 2005-2008 Martin Kaltenbrunner <mkalten@iua.upf.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

import java.util.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;
import com.illposed.osc.*;

public class Simulation extends JComponent implements Runnable {

	private Manager manager;
	private OSCPortOut oscPort;

	private int currentFrame = 0;	
	private long lastFrameTime = -1;
	private int session_id = 0;
	private int cursor_id  = 0;

	private final float halfPi = (float)(Math.PI/2);
	private final float doublePi = (float)(Math.PI*2);

	Shape vision, vision_rectangle, vision_circle;
	Shape table_border,table_surface,table_circle;
	private Stroke normalStroke = new BasicStroke(2.0f);	
	private Stroke borderStroke = new BasicStroke(8.0f);
	private Color borderColor = new Color(0,200,0);
	private Stroke gestureStroke = new BasicStroke(1.0f);
	
	int selObj = -1;
	int selCur = -1;
	int lastX = -1;
	int lastY = -1;
	int clickX = 0;
	int clickY = 0;
	//boolean mouseDown = false;
	Vector<Integer> stickyCursors = new Vector<Integer>();
	Vector<Integer> jointCursors = new Vector<Integer>();
	
	
	boolean showName = false;
	int nameId, namex, namey;
	String objectName = "";

	private boolean running = false;
	
	int window_width = TuioSimulator.width;
	int window_height = TuioSimulator.height;
	int table_width = (int)(TuioSimulator.width/1.25);
	int table_height = (int)(TuioSimulator.height/1.25);
	int border_width = (int)(window_width-table_width)/2;
	int border_height = (int)(window_height-table_height)/2;
	
	public Simulation(Manager manager, String host, int port) {
		super();
		this.manager=manager;
		session_id = manager.objectList.size();
		
		try { oscPort = new OSCPortOut(java.net.InetAddress.getByName(host),port); }
		catch (Exception e) { oscPort = null; }
		reset();

		String cursorName="cursor16.gif";
		Point cursorPoint=new Point(0,0);
		double cw = Toolkit.getDefaultToolkit().getBestCursorSize(16,16).getWidth();	
		if (cw==32) { cursorName = "cursor32.gif"; cursorPoint = new Point(8,8); }
		if (cw==64) { cursorName = "cursor64.gif"; cursorPoint = new Point(24,24); }
	
		Image cursorImage = Toolkit.getDefaultToolkit().createImage("resources"+System.getProperty("file.separator")+cursorName);
		Cursor cursor = Toolkit.getDefaultToolkit().createCustomCursor(cursorImage,cursorPoint,"myCursor");
		setCursor(cursor);

		String  os = System.getProperty("os.name");
		if (os.equals("Mac OS X")) RepaintManager.currentManager(this).setDoubleBufferingEnabled(false);

		// init the table setup
		vision_rectangle = new Area(new Rectangle2D.Float(border_width-6,border_height-6,table_width+12,table_height+12));
		vision_circle = new Area(new Ellipse2D.Float((table_width-table_height)/2+border_width-6,border_height-6,table_height+12,table_height+12));
		vision = vision_rectangle;
		
		table_border = new Rectangle2D.Float(0,0,window_width,window_height);
		table_surface = new Rectangle2D.Float(border_width,border_height,table_width,table_height);
		table_circle = new Ellipse2D.Float((window_width-table_height)/2,border_height,table_height,table_height);

		// listens to the mouseDown event
		addMouseListener (
			new MouseAdapter () {
				public void mousePressed (MouseEvent evt) {
					mouse_pressed(evt);

				}
			}
		);

		// listens to the mouseDragged event
		addMouseMotionListener (
			new MouseMotionAdapter () {
				public void mouseDragged (MouseEvent evt) {
					mouse_dragged(evt);
				}
			}
		);
		
		// listens to the mouseReleased event
		addMouseListener (
			new MouseAdapter () {
				public void mouseReleased (MouseEvent evt) {
					mouse_released(evt);
				}
			}
		);

		// listens to the mouseMoved event
		addMouseMotionListener (
			new MouseMotionAdapter () {
				public void mouseMoved (MouseEvent evt) {
					mouse_moved(evt);
				}
			}
		);
	}

	public void limit (boolean circular) {
		
		if (circular) vision = vision_circle;
		else vision = vision_rectangle;
		
		Enumeration<Tangible> objectList = manager.objectList.elements();
			while (objectList.hasMoreElements()) {
				Tangible tangible = objectList.nextElement();
				if (vision.contains(tangible.geom.getBounds2D())) {
					if (!tangible.isActive()) {
						session_id++;
						manager.activate(tangible.session_id,session_id);
						setMessageBundle(tangible);
					}
				} else {
					if (tangible.isActive()) {
						manager.deactivate(tangible.session_id);
						setMessageBundle(tangible);
					}
				}
		}
	}

	private void sendOSC(OSCPacket packet) {
		try { oscPort.send(packet); }
		catch (java.io.IOException e) {}
	}

	private OSCMessage setMessage(Tangible tangible) {		
		
		OSCMessage setMessage = new OSCMessage("/tuio/2Dobj");
		setMessage.addArgument("set");
		setMessage.addArgument(tangible.session_id);
		setMessage.addArgument(tangible.fiducial_id);
		setMessage.addArgument((tangible.getPosition().x-border_width)/(float)table_width);
		setMessage.addArgument((tangible.getPosition().y-border_height)/(float)table_height);
		setMessage.addArgument(tangible.getAngle());
		setMessage.addArgument(tangible.xspeed);
		setMessage.addArgument(tangible.yspeed);
		setMessage.addArgument(tangible.rspeed);
		setMessage.addArgument(tangible.maccel);
		setMessage.addArgument(tangible.raccel);
		return setMessage;
	}

	private void cursorDelete() {
		
		OSCBundle cursorBundle = new OSCBundle();

		OSCMessage remoteMessage = new OSCMessage("/tuio/2Dcur");
		remoteMessage.addArgument("source");
		remoteMessage.addArgument("simulator");

		OSCMessage aliveMessage = new OSCMessage("/tuio/2Dcur");
		aliveMessage.addArgument("alive");
		Enumeration<Integer> cursorList = manager.cursorList.keys();
		while (cursorList.hasMoreElements()) {
			Integer s_id = cursorList.nextElement();
			aliveMessage.addArgument(s_id);
		}

		currentFrame++;
		OSCMessage frameMessage = new OSCMessage("/tuio/2Dcur");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(currentFrame);
		
		cursorBundle.addPacket(remoteMessage);
		cursorBundle.addPacket(aliveMessage);
		cursorBundle.addPacket(frameMessage);

		sendOSC(cursorBundle);
	}

	private void cursorMessage() {

		OSCBundle cursorBundle = new OSCBundle();

		OSCMessage remoteMessage = new OSCMessage("/tuio/2Dcur");
		remoteMessage.addArgument("source");
		remoteMessage.addArgument("simulator");

		OSCMessage aliveMessage = new OSCMessage("/tuio/2Dcur");
		aliveMessage.addArgument("alive");

		Enumeration<Integer> cursorList = manager.cursorList.keys();
		while (cursorList.hasMoreElements()) {
			Integer s_id = cursorList.nextElement();
			aliveMessage.addArgument(s_id);
		}

		Finger cursor = manager.cursorList.get(selCur);
		Point point = cursor.getPosition();
		OSCMessage setMessage = new OSCMessage("/tuio/2Dcur");
		setMessage.addArgument("set");
		setMessage.addArgument(cursor.session_id);
		setMessage.addArgument(new Float((point.x-border_width)/(float)table_width));
		setMessage.addArgument(new Float((point.y-border_height)/(float)table_height));
		setMessage.addArgument(new Float(cursor.xspeed));
		setMessage.addArgument(new Float(cursor.yspeed));
		setMessage.addArgument(new Float(cursor.maccel));

		currentFrame++;
		OSCMessage frameMessage = new OSCMessage("/tuio/2Dcur");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(currentFrame);
		
		cursorBundle.addPacket(remoteMessage);
		cursorBundle.addPacket(aliveMessage);
		cursorBundle.addPacket(setMessage);
		cursorBundle.addPacket(frameMessage);

		if (manager.verbose) {
			System.out.println("set cur "+cursor.session_id+" "+(point.x-border_width)/(float)table_width+" "+(point.y-border_height)/(float)table_height+" "+cursor.xspeed+" "+cursor.yspeed+" "+cursor.maccel);
		}
		sendOSC(cursorBundle);
	}

	private void setMessageBundle(Tangible tangible) {

		OSCBundle oscBundle = new OSCBundle();

		OSCMessage remoteMessage = new OSCMessage("/tuio/2Dobj");
		remoteMessage.addArgument("source");
		remoteMessage.addArgument("simulator");

		OSCMessage aliveMessage = new OSCMessage("/tuio/2Dobj");
		aliveMessage.addArgument("alive");

		Enumeration objectList = manager.objectList.elements();
		while (objectList.hasMoreElements()) {
			Tangible test = (Tangible)objectList.nextElement();
			if (test.isActive())
				aliveMessage.addArgument(new Integer(test.session_id));
		}

		OSCMessage setMessage = setMessage(tangible);
		if (manager.verbose) System.out.println("set obj "+tangible.session_id+" "+tangible.fiducial_id+" "+(tangible.getPosition().x-border_width)/(float)table_width+" "+(tangible.getPosition().y-border_height)/(float)table_height+" "+tangible.getAngle()+" "+tangible.xspeed+" "+tangible.yspeed+" "+tangible.rspeed+" "+tangible.maccel+" "+tangible.raccel);

		currentFrame++;
		OSCMessage frameMessage = new OSCMessage("/tuio/2Dobj");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(currentFrame);

		oscBundle.addPacket(remoteMessage);
		oscBundle.addPacket(aliveMessage);
		oscBundle.addPacket(setMessage);
		oscBundle.addPacket(frameMessage);
		
		sendOSC(oscBundle);
	}

	public void aliveMessage() {

		OSCBundle oscBundle = new OSCBundle();

		OSCMessage remoteMessage = new OSCMessage("/tuio/2Dobj");
		remoteMessage.addArgument("source");
		remoteMessage.addArgument("simulator");

		OSCMessage aliveMessage = new OSCMessage("/tuio/2Dobj");
		aliveMessage.addArgument("alive");

		Enumeration objectList = manager.objectList.elements();
		while (objectList.hasMoreElements()) {
			Tangible tangible = (Tangible)objectList.nextElement();
			if (tangible.isActive())
				aliveMessage.addArgument(new Integer(tangible.session_id));
		}
		
		currentFrame++;
		OSCMessage frameMessage = new OSCMessage("/tuio/2Dobj");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(currentFrame);

		oscBundle.addPacket(remoteMessage);
		oscBundle.addPacket(aliveMessage);
		oscBundle.addPacket(frameMessage);
		
		sendOSC(oscBundle);
	}

	private void completeCursorMessage() {
		
		Vector<OSCMessage> messageList = new Vector<OSCMessage>(manager.objectList.size());
		
		OSCMessage frameMessage = new OSCMessage("/tuio/2Dcur");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(-1);
		
		OSCMessage remoteMessage = new OSCMessage("/tuio/2Dcur");
		remoteMessage.addArgument("source");
		remoteMessage.addArgument("simulator");	
		
		OSCMessage aliveMessage = new OSCMessage("/tuio/2Dcur");
		aliveMessage.addArgument("alive");
		
		Enumeration cursorList = manager.cursorList.keys();
		while (cursorList.hasMoreElements()) {
			Integer s_id = (Integer)cursorList.nextElement();
			aliveMessage.addArgument(s_id);

			Finger cursor = manager.cursorList.get(s_id);
			Point point = cursor.getPosition();
					
			OSCMessage setMessage = new OSCMessage("/tuio/2Dcur");
			setMessage.addArgument("set");
			setMessage.addArgument(s_id);
			setMessage.addArgument(new Float((point.x-border_width)/(float)table_width));
			setMessage.addArgument(new Float((point.y-border_height)/(float)table_height));
			setMessage.addArgument(new Float(cursor.xspeed));
			setMessage.addArgument(new Float(cursor.yspeed));
			setMessage.addArgument(new Float(cursor.maccel));
			messageList.addElement(setMessage);
		}
		
		int i;
		for (i=0;i<(messageList.size()/5);i++) {
			OSCBundle oscBundle = new OSCBundle();
			
			oscBundle.addPacket(remoteMessage);
			oscBundle.addPacket(aliveMessage);
			
			for (int j=0;j<5;j++)
				oscBundle.addPacket((OSCPacket)messageList.elementAt(i*5+j));
			
			if (messageList.size()<=5) oscBundle.addPacket(frameMessage);
			sendOSC(oscBundle);
		} 
		
		if ((messageList.size()%5!=0) || (messageList.size()==0)) {
			OSCBundle oscBundle = new OSCBundle();
			
			oscBundle.addPacket(remoteMessage);
			oscBundle.addPacket(aliveMessage);
			
			for (int j=0;j<messageList.size()%5;j++)
				oscBundle.addPacket((OSCPacket)messageList.elementAt(i*5+j));	
			
			oscBundle.addPacket(frameMessage);
			sendOSC(oscBundle);
		}
	}
	
	private void completeObjectMessage() {

		Vector<OSCMessage> messageList = new Vector<OSCMessage>(manager.objectList.size());

		OSCMessage frameMessage = new OSCMessage("/tuio/2Dobj");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(-1);
	
		OSCMessage remoteMessage = new OSCMessage("/tuio/2Dobj");
		remoteMessage.addArgument("source");
		remoteMessage.addArgument("simulator");	

		OSCMessage aliveMessage = new OSCMessage("/tuio/2Dobj");
		aliveMessage.addArgument("alive");

		Enumeration objectList = manager.objectList.elements();
		while (objectList.hasMoreElements()) {
			Tangible tangible = (Tangible)objectList.nextElement();
			try {
				if (tangible.isActive()) {
					messageList.addElement(setMessage(tangible));
					aliveMessage.addArgument(tangible.session_id);
				}
			} catch (Exception e) { return; }
		}

		int i;
		for (i=0;i<(messageList.size()/5);i++) {
			OSCBundle oscBundle = new OSCBundle();
	
			oscBundle.addPacket(remoteMessage);
			oscBundle.addPacket(aliveMessage);

			for (int j=0;j<5;j++)
				oscBundle.addPacket((OSCPacket)messageList.elementAt(i*5+j));
	
			if (messageList.size()<=5) oscBundle.addPacket(frameMessage);
			sendOSC(oscBundle);
		} 

		if ((messageList.size()%5!=0) || (messageList.size()==0)) {
			OSCBundle oscBundle = new OSCBundle();
		
			oscBundle.addPacket(remoteMessage);
			oscBundle.addPacket(aliveMessage);
	
			for (int j=0;j<messageList.size()%5;j++)
				oscBundle.addPacket((OSCPacket)messageList.elementAt(i*5+j));	
	
			oscBundle.addPacket(frameMessage);
			sendOSC(oscBundle);
		}
	}

	public void quit() {
		reset();
		running = false;
	}

	public void reset() {
		session_id = manager.objectList.size();
		cursor_id=0;
		stickyCursors.clear();
		jointCursors.clear();
		
		lastFrameTime = -1;
		
		OSCBundle objBundle = new OSCBundle();

		OSCMessage sourceMessage = new OSCMessage("/tuio/2Dobj");
		sourceMessage.addArgument("source");
		sourceMessage.addArgument("simulator");

		OSCMessage aliveMessage = new OSCMessage("/tuio/2Dobj");
		aliveMessage.addArgument("alive");

		OSCMessage frameMessage = new OSCMessage("/tuio/2Dobj");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(-1);

		objBundle.addPacket(sourceMessage);
		objBundle.addPacket(aliveMessage);
		objBundle.addPacket(frameMessage);		
		sendOSC(objBundle);
		
		OSCBundle curBundle = new OSCBundle();

		sourceMessage = new OSCMessage("/tuio/2Dcur");
		sourceMessage.addArgument("source");
		sourceMessage.addArgument("simulator");
		
		aliveMessage = new OSCMessage("/tuio/2Dcur");
		aliveMessage.addArgument("alive");
		
		frameMessage = new OSCMessage("/tuio/2Dcur");
		frameMessage.addArgument("fseq");
		frameMessage.addArgument(-1);
		
		curBundle.addPacket(sourceMessage);
		curBundle.addPacket(aliveMessage);
		curBundle.addPacket(frameMessage);		
		sendOSC(curBundle);
	}

	public void paint(Graphics g) {
		update(g);
	}

	public void update(Graphics g) {
	
		// setup the graphics environment
		Graphics2D g2 = (Graphics2D)g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
		g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		//g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_DEFAULT);

		// draw the table & border
		g2.setPaint(Color.gray);
		g2.fill(table_border);
		g2.setPaint(Color.white);
		g2.fill(table_surface);

		//draw the round table edge
		g2.setPaint(Color.lightGray);
		g2.draw(table_circle);

		// paint the cursors
		Enumeration<Finger> cursorList = manager.cursorList.elements();
		while (cursorList.hasMoreElements()) {
			Finger cursor = cursorList.nextElement();
			Vector<Point> gesture = cursor.getPath();
			if (gesture.size()>0) {
				g2.setPaint(Color.blue);
				g2.setStroke(gestureStroke);
				Point start = gesture.elementAt(0);
				for (int i=0;i<gesture.size();i++) {
					Point end  = gesture.elementAt(i);
					g2.draw(new Line2D.Double(start.getX(),start.getY(),end.getX(),end.getY()));
					start = end;
				}
				if (jointCursors.contains(cursor.session_id)) g2.setPaint(Color.darkGray);
				else g2.setPaint(Color.lightGray);
				g2.fill(new Ellipse2D.Double(start.getX()-5,start.getY()-5,10,10));
			}
		}

		// paint the objects
		Enumeration objectList = manager.objectList.elements();
		while (objectList.hasMoreElements()) {
			Tangible tangible = (Tangible)objectList.nextElement();

			// draw the border
			if (tangible.isActive()) {
				g2.setStroke(borderStroke);
				g2.setPaint(borderColor);
				g2.draw(tangible.geom);
			}

			// draw the objects
			g2.setPaint(tangible.color);
			g2.fill(tangible.geom);

			// draw the rotation mark
			g2.setPaint(Color.black);
			g2.setStroke(normalStroke);
			g2.draw(new Line2D.Float(tangible.getPosition(),tangible.getPointer()));
			if ((tangible.previous!=null)  && (tangible.next!=null))
				g2.fillOval(tangible.getPosition().x-3,tangible.getPosition().y-3,6,6);

			// draw the object id
			g2.setPaint(Color.white);
			g2.drawString(tangible.fiducial_id+"",tangible.getPosition().x+2,tangible.getPosition().y);
		}

		// draw the object name
		if (showName) {
			int boxwidth = getFontMetrics(getFont()).stringWidth(objectName)+12;
			g2.setPaint(Color.white);
			g2.fill(new Rectangle2D.Float(namex,namey,boxwidth,16));
			g2.setPaint(Color.blue);
			g2.draw(new Rectangle2D.Float(namex,namey,boxwidth,16));
			g2.drawString(objectName,namex+6,namey+12);
		}
	}
 
	public final void switchSide(int old_id, int increment) {
	
		Tangible tangible = (Tangible)manager.objectList.get(new Integer(old_id));
		if ((tangible.previous!=null) && (tangible.previous!=null)) {
							
			int x_save = tangible.getPosition().x;
			int y_save = tangible.getPosition().y;
			float a_save =  tangible.getAngle();

			Tangible new_side = tangible;
			if (increment>0) new_side = tangible.next;
			else  if (increment<0) new_side = tangible.previous;	
			selObj = new_side.session_id;

			manager.deactivate(old_id);
			manager.update(old_id,-100,-100,a_save);
			manager.update(selObj,x_save,y_save,a_save);
			aliveMessage();

		}
	}

	public void mouse_dragged (MouseEvent evt) {

		long currentFrameTime = System.currentTimeMillis();
		long dt = currentFrameTime - lastFrameTime;
		if (dt<20) return;

		Point pt = evt.getPoint();
		int x = (int)pt.getX();
		int y = (int)pt.getY();
		
		if (selObj>-1){
			Tangible selObject = manager.objectList.get(selObj);
			if (selObject==null) { System.out.println(selObj); return; }
			//System.out.println(evt.getModifiers());
			switch (evt.getModifiers()) {
				// translation
				case 17: {
					// deactivate
					manager.deactivate(selObj);
					//move the object
					manager.update(selObj,x+clickX,y+clickY,selObject.getAngle());
					//setMessageBundle(selObj,x,y,selObject.getAngle(),speed,accel);
					aliveMessage();

					break;
				}
				case 16: {
					//move the object
					manager.update(selObj,x+clickX,y+clickY,selObject.getAngle());

					// activate
					if (vision.contains(selObject.geom.getBounds2D())) {
						if (!selObject.isActive()) {
							session_id++;
							manager.activate(selObj,session_id);
							selObj = session_id;
						}
						setMessageBundle(selObject);
						//aliveMessage();
					} else { 
						manager.deactivate(selObj);
						aliveMessage();
					}
					break;
				}
				// rotation
				case 4: {
					int diff = lastY-y;
					if (diff>15) diff = 15;
					if (diff<-15) diff = -15;
					float newAngle = (float)(selObject.getAngle()+(Math.PI/90*diff));
					if(newAngle<0) newAngle+=doublePi;
					if(newAngle>doublePi) newAngle-=doublePi;
					manager.update(selObject.session_id,selObject.getPosition().x,selObject.getPosition().y,newAngle);
					if (selObject.isActive())
						setMessageBundle(selObject);
					break;
				}
			
				// switch sides
				case 21: //mac
				case 5: {
					int diff = lastY-y;
					if (diff>=3) switchSide(selObj,-1);
					if (diff<=-3) switchSide(selObj,1);
					break;
				}
			}
			
			} else if (selCur>-1){
				if (vision.contains(pt)) {
					
					if (jointCursors.contains(selCur)) {
					int dx = 0;
					int dy = 0;
					Point selPoint = manager.getCursorPosition(selCur);
					if (selPoint!=null) {
						dx = pt.x - manager.getCursorPosition(selCur).x;
						dy = pt.y - manager.getCursorPosition(selCur).y;
					}
					
					Enumeration<Integer> joints = jointCursors.elements();
					while (joints.hasMoreElements()) {
						int jointId = joints.nextElement();
						if (jointId == selCur) continue;
						Point joint_point = manager.getCursorPosition(jointId);
						if (joint_point!=null) manager.updateCursor(jointId, joint_point.x+dx,joint_point.y+dy);
					}
						manager.updateCursor(selCur,pt.x,pt.y);
						completeCursorMessage();
					} else {
					
						manager.updateCursor(selCur,pt.x,pt.y);
						cursorMessage();
					}
				} else {
					if (manager.verbose) System.out.println("del cur "+selCur);
					if (stickyCursors.contains(selCur)) stickyCursors.remove(selCur);
					if (jointCursors.contains(selCur)) jointCursors.remove(selCur);
					manager.terminateCursor(selCur);
					cursorDelete();
					selCur = -1;
					cursor_id++;				
				}
			}

			lastX = x;
			lastY = y;
			
			lastFrameTime = currentFrameTime;
	}

	public void mouse_moved(MouseEvent evt) {

		if (evt.getModifiers()==2) {

			int x = evt.getX();
			int y = evt.getY();
				
			Enumeration objectList = manager.objectList.elements();
			while (objectList.hasMoreElements()) {
				Tangible tangible = (Tangible)objectList.nextElement();
				if (tangible.containsPoint(x,y)) {
	
					objectName = tangible.type.description;
					showName=true;
					nameId = tangible.fiducial_id;
					namex = x+24;
					namey = y;

					repaint();
					return;
				} 
			} 

			if (showName) {
				showName = false;
				repaint();
			}
		} else if (showName)  {
			showName = false;
			repaint();
		}
	}

	public void mouse_pressed (MouseEvent evt) {
		int x = evt.getX();
		int y = evt.getY();
				
		Enumeration objectList = manager.objectList.elements();
		while (objectList.hasMoreElements()) {
			Tangible tangible = (Tangible)objectList.nextElement();
			if (tangible.containsPoint(x,y)) {
				selObj = tangible.session_id;
				selCur = -1;
			
				clickX = tangible.getPosition().x-x;
				clickY = tangible.getPosition().y-y;

				lastX = x;
				lastY = y;
				return;
			}
		}

		Enumeration<Finger> cursorList = manager.cursorList.elements();
		while (cursorList.hasMoreElements()) {
			Finger cursor = cursorList.nextElement();
			Point point = cursor.getPosition();
			if (point.distance(x,y)<7) {

				if (((evt.getModifiers() & InputEvent.SHIFT_MASK) > 0) && selCur != cursor.session_id) {
					if (manager.verbose) System.out.println("del cur "+cursor.session_id);
					stickyCursors.removeElement(cursor.session_id);
					manager.terminateCursor(cursor.session_id);
					cursorDelete();
					selCur = -1;
					//cursor_id++;
					return;
				} else if ((evt.getModifiers() & InputEvent.CTRL_MASK) > 0) {
					if (jointCursors.contains(cursor.session_id)) jointCursors.removeElement(cursor.session_id);
					else jointCursors.addElement(cursor.session_id);
					repaint();
					return;
				} else {
					selCur = cursor.session_id;
					selObj = -1;
				
					lastX = x;
					lastY = y;
					return;
				} 
			}
		}
			
		if ((evt.getModifiers() & InputEvent.CTRL_MASK) > 0) return;
		
		if (vision.contains(new Point(x, y))) {
			selCur = cursor_id;
			if (manager.verbose) System.out.println("add cur "+selCur);
			manager.updateCursor(selCur,x,y);
			cursorMessage();
			if ((evt.getModifiers() & InputEvent.SHIFT_MASK) > 0) stickyCursors.addElement(selCur);
			return;
		}


		selObj = -1;
		selCur = -1;
		lastX = -1;
		lastY = -1;
	}

	public void mouse_released (MouseEvent evt) {

		if ( (selObj>-1) /*&& (mouseDown)*/ )  {

			Tangible tangible = manager.objectList.get(selObj);
			if (tangible==null) { System.out.println(selObj); return; }
			
			// activate if inside the table
			if (vision.contains(tangible.geom.getBounds2D())) {
				if (!tangible.isActive()) {
					session_id++;
					manager.activate(selObj,session_id);
					selObj = session_id;
				} else tangible.stop();
				setMessageBundle(tangible);
			} else {
				manager.deactivate(selObj);
				aliveMessage();
			}

			selObj = -1;
		} else if ( (selCur>-1) )  {
			
			if (!stickyCursors.contains(new Integer(selCur))) {
				if (manager.verbose) System.out.println("del cur "+ selCur);
				if (jointCursors.contains(selCur)) jointCursors.remove(selCur);
				manager.terminateCursor(selCur);
				cursorDelete();
			} else {
				manager.stopCursor(selCur);
				cursorMessage();
			}
			
			selCur = -1;
			cursor_id++;
		}

		//mouseDown = false;
	}

	// send table state every second
	public void run() {
		running = true;
		while(running) {
			try { Thread.sleep(1000); }
			catch (Exception e) {}
			completeObjectMessage();
			completeCursorMessage();
		}
	}
}
